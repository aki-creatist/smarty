<?php
/* Smarty version 3.1.30, created on 2017-12-29 06:49:05
  from "/var/www/html/answer/day_05/01/smarty/templates/01.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a4566d1043c09_73822453',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9af735490443545c5e6787a7bc9867f284558617' => 
    array (
      0 => '/var/www/html/answer/day_05/01/smarty/templates/01.tpl',
      1 => 1514497725,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a4566d1043c09_73822453 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>お問い合わせフォーム</title>
    <?php echo '<script'; ?>
 src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="./errorCheck.js"><?php echo '</script'; ?>
>
</head>
<body>

<form method="post" action="" enctype="multipart/form-data">
    <table border="1px">
        <tr>
            <th>名前</th>
            <td>
                <input type="text" name="name" id="name_id" value="<?php echo $_smarty_tpl->tpl_vars['posted_data']->value['name'];?>
" />
                <?php if ($_smarty_tpl->tpl_vars['err_msg']->value['name'] != '') {?>
                    <span class="red"><?php echo $_smarty_tpl->tpl_vars['err_msg']->value['name'];?>
</span>
                <?php }?>
            </td>
        </tr>
        <tr>
            <th>年齢</th>
            <td>
                <input type="text" name="age" id="age_id" value="<?php echo $_smarty_tpl->tpl_vars['posted_data']->value['age'];?>
" size="2" maxlength="3" />
                <?php if ($_smarty_tpl->tpl_vars['err_msg']->value['age'] != '') {?><br />
                    <span class="red"><?php echo $_smarty_tpl->tpl_vars['err_msg']->value['age'];?>
</span>
                <?php }?>
            </td>
        </tr>
        <tr>
            <th>画像</th>
            <td>
                <input type="file" name="image" />
                <?php if ($_smarty_tpl->tpl_vars['err_msg']->value['image'] != '') {?><br />
                    <span class="red"><?php echo $_smarty_tpl->tpl_vars['err_msg']->value['image'];?>
</span>
                <?php }?>
            </td>
        </tr>
        <tr>
            <th>性別</th>
            <td>
                <input type="radio" name="sex" value="男" id="man_id" <?php if ('selected_gender' == '男') {?>checked<?php }?> />男
                <input type="radio" name="sex" value="女" id="woman_id"<?php if ('selected_gender' == '女') {?>checked<?php }?> />女
                <?php if ($_smarty_tpl->tpl_vars['err_msg']->value['sex'] != '') {?><br />
                    <span class="red"><?php echo $_smarty_tpl->tpl_vars['err_msg']->value['sex'];?>
</span>
                <?php }?>
            </td>
        </tr>
        <tr>
            <th>言語</th>
            <td>
                <select  name="language" id="language_id">
                    <option value="">言語を選んでください。</option>
                    <option value="C/C++" <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "C/C++")) {?>selected<?php }?>>C/C++</option>
                    <option value="Java"  <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "Java")) {?>selected<?php }?>>Java</option>
                    <option value="C#"    <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "C#")) {?>selected<?php }?>>C#</option>
                    <option value="PHP"   <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "PHP")) {?>selected<?php }?>>PHP</option>
                    <option value="Perl"  <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "Perl")) {?>selected<?php }?>>Perl</option>
                    <option value="Ruby"  <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "Ruby")) {?>selected<?php }?>>Ruby</option>
                </select>
                <?php if ($_smarty_tpl->tpl_vars['err_msg']->value['language'] != '') {?><br />
                    <span class="red"><?php echo $_smarty_tpl->tpl_vars['err_msg']->value['language'];?>
</span>
                <?php }?>
            </td>
        </tr>
        <tr>
            <td align="left">
                <input type="submit" name="send" id="sendButton" value="送信" />
            </td>
        </tr>
    </table>
</form>

<table border="1px">
    <tr>
        <th>名前</th>
        <th>年齢</th>
        <th>性別</th>
        <th>言語</th>
        <th>画像</th>
    </tr>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrMember']->value, 'member', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['member']->value) {
?>
    <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['member']->value['name'];?>
</td>
        <td><?php echo $_smarty_tpl->tpl_vars['member']->value['age'];?>
</td>
        <td><?php echo $_smarty_tpl->tpl_vars['member']->value['sex'];?>
</td>
        <td><?php echo $_smarty_tpl->tpl_vars['member']->value['language'];?>
</td>
        <td>
            <?php if ($_smarty_tpl->tpl_vars['member']->value['image'] != '') {?>
                <img src ="image/<?php echo $_smarty_tpl->tpl_vars['member']->value["image"];?>
" width="50%">
            <?php }?>
        </td>
    </tr>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</table>
</body>
</html><?php }
}
