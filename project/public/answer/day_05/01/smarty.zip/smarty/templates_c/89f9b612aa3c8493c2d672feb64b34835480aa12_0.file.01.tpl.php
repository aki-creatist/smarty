<?php
/* Smarty version 3.1.30, created on 2017-12-29 06:00:16
  from "/var/www/html/answer/day_04/02/smarty/templates/01.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a455b6019e828_50928563',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '89f9b612aa3c8493c2d672feb64b34835480aa12' => 
    array (
      0 => '/var/www/html/answer/day_04/02/smarty/templates/01.tpl',
      1 => 1514494800,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a455b6019e828_50928563 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>お問い合わせフォーム</title>
</head>
<body>

<form method="post" action="" enctype="multipart/form-data">
    <table border="1px">
        <tr>
            <th>名前</th>
            <td>
                <input type="text" name="name" value="<?php echo $_smarty_tpl->tpl_vars['posted_data']->value['name'];?>
" />
                <?php if ($_smarty_tpl->tpl_vars['err_msg']->value['name'] != '') {?>
                    <span class="red"><?php echo $_smarty_tpl->tpl_vars['err_msg']->value['name'];?>
</span>
                <?php }?>
            </td>
        </tr>
        <tr>
            <th>年齢</th>
            <td>
                <input type="text" name="age" value="<?php echo $_smarty_tpl->tpl_vars['posted_data']->value['age'];?>
" size="2" maxlength="3"/>
                <?php if ($_smarty_tpl->tpl_vars['err_msg']->value['age'] != '') {?><br />
                    <span class="red"><?php echo $_smarty_tpl->tpl_vars['err_msg']->value['age'];?>
</span>
                <?php }?>
            </td>
        </tr>
        <tr>
            <th>画像</th>
            <td>
                <input type="file" name="image"  />
                <?php if ($_smarty_tpl->tpl_vars['err_msg']->value['image'] != '') {?><br />
                    <span class="red"><?php echo $_smarty_tpl->tpl_vars['err_msg']->value['image'];?>
</span>
                <?php }?>
            </td>
        </tr>
        <tr>
            <th>性別</th>
            <td>
                <input type="radio" name="sex" value="男" <?php if ('selected_gender' == '男') {?>checked<?php }?> />男
                <input type="radio" name="sex" value="女" <?php if ('selected_gender' == '女') {?>checked<?php }?>/>女
                <?php if ($_smarty_tpl->tpl_vars['err_msg']->value['sex'] != '') {?><br />
                    <span class="red"><?php echo $_smarty_tpl->tpl_vars['err_msg']->value['sex'];?>
</span>
                <?php }?>
            </td>
        </tr>
        <tr>
            <th>言語</th>
            <td>
                <select  name="language">
                    <option value="">言語を選んでください。</option>
                    <option value="C/C++" <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "C/C++")) {?>selected<?php }?>>C/C++</option>
                    <option value="Java"  <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "Java")) {?>selected<?php }?>>Java</option>
                    <option value="C#"    <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "C#")) {?>selected<?php }?>>C#</option>
                    <option value="PHP"   <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "PHP")) {?>selected<?php }?>>PHP</option>
                    <option value="Perl"  <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "Perl")) {?>selected<?php }?>>Perl</option>
                    <option value="Ruby"  <?php if (($_smarty_tpl->tpl_vars['selected_language']->value === "Ruby")) {?>selected<?php }?>>Ruby</option>
                </select>
                <?php if ($_smarty_tpl->tpl_vars['err_msg']->value['language'] != '') {?><br />
                    <span class="red"><?php echo $_smarty_tpl->tpl_vars['err_msg']->value['language'];?>
</span>
                <?php }?>
            </td>
        </tr>
        <tr>
            <td align="left">
                <input type="submit" name="send"  value="送信" />
            </td>
        </tr>
    </table>
</form>

<table border="1px">
    <tr>
        <th>名前</th>
        <th>年齢</th>
        <th>性別</th>
        <th>言語</th>
        <th>画像</th>
    </tr>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrMember']->value, 'member', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['member']->value) {
?>
    <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['member']->value['name'];?>
</td>
        <td><?php echo $_smarty_tpl->tpl_vars['member']->value['age'];?>
</td>
        <td><?php echo $_smarty_tpl->tpl_vars['member']->value['sex'];?>
</td>
        <td><?php echo $_smarty_tpl->tpl_vars['member']->value['language'];?>
</td>
        <td>
            <?php if ($_smarty_tpl->tpl_vars['member']->value['image'] != '') {?>
                <img src ="image/<?php echo $_smarty_tpl->tpl_vars['member']->value["image"];?>
" width="50%">
            <?php }?>
        </td>
    </tr>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</table>
</body>
</html><?php }
}
