<?php
/* Smarty version 3.1.30, created on 2017-09-15 03:54:01
  from "/Applications/XAMPP/xamppfiles/htdocs/Smarty/demo/templates/header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59bb32b9240970_62508903',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '56d85c3b1db906aa8d4da4c0aa059a366046b47f' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/Smarty/demo/templates/header.tpl',
      1 => 1470538008,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59bb32b9240970_62508903 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '145200106959bb32b923fd24_29877376';
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:145200106959bb32b923fd24_29877376%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:145200106959bb32b923fd24_29877376%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
