<?php
/* Smarty version 3.1.30, created on 2017-09-15 03:54:01
  from "/Applications/XAMPP/xamppfiles/htdocs/Smarty/demo/templates/footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59bb32b924a3c2_96657415',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b25b5d5cd025a0561cb1488a3ec569fc9ddb6f69' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/Smarty/demo/templates/footer.tpl',
      1 => 1470538008,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59bb32b924a3c2_96657415 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '205303577359bb32b9249905_74311578';
?>
</BODY>
</HTML>
<?php }
}
