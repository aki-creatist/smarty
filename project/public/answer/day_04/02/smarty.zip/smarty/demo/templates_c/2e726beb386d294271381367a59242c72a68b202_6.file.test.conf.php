<?php /* Smarty version 3.1.30, created on 2017-09-15 03:58:00
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/smarty/demo/configs/test.conf" */ ?>
<?php
/* Smarty version 3.1.30, created on 2017-09-15 03:58:00
  from "/Applications/XAMPP/xamppfiles/htdocs/smarty/demo/configs/test.conf" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59bb33a8279cb2_38947309',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2e726beb386d294271381367a59242c72a68b202' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/smarty/demo/configs/test.conf',
      1 => 1470538008,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59bb33a8279cb2_38947309 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
));
}
}
