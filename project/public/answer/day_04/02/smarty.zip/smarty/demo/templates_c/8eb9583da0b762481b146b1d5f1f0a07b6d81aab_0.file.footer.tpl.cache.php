<?php
/* Smarty version 3.1.30, created on 2017-09-15 03:58:00
  from "/Applications/XAMPP/xamppfiles/htdocs/smarty/demo/templates/footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59bb33a82807f3_70950503',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8eb9583da0b762481b146b1d5f1f0a07b6d81aab' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/smarty/demo/templates/footer.tpl',
      1 => 1470538008,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59bb33a82807f3_70950503 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '93360194959bb33a8280345_94015820';
?>
</BODY>
</HTML>
<?php }
}
