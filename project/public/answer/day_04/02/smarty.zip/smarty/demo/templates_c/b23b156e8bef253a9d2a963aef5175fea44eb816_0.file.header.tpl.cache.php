<?php
/* Smarty version 3.1.30, created on 2017-09-15 03:58:00
  from "/Applications/XAMPP/xamppfiles/htdocs/smarty/demo/templates/header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59bb33a827c518_15439615',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'b23b156e8bef253a9d2a963aef5175fea44eb816' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/smarty/demo/templates/header.tpl',
      1 => 1470538008,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59bb33a827c518_15439615 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '47797383459bb33a827b718_66049155';
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:47797383459bb33a827b718_66049155%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:47797383459bb33a827b718_66049155%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
